package com.cognizant.samples;

public class ResultCalculation {

}
