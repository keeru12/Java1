package com.cognizant.samples;

public class Employee {

}
