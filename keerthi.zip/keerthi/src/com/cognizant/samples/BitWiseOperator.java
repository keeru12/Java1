package com.cognizant.samples;

public class BitWiseOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
