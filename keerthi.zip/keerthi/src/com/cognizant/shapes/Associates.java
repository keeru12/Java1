package com.cognizant.shapes;

public class Associates {

}
