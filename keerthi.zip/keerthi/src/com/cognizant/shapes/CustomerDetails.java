package com.cognizant.shapes;

public class CustomerDetails {

}
