package com.cognizant.shapes;

public class Rectangle {
	int length, breadth;
	void CalculateArea()
	{
	System.out.println("The area of the Rectangle is "+(length*breadth));
	}



	

}
