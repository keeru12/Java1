package com.cognizant.shapes;

public interface AssociatesDao {

}
