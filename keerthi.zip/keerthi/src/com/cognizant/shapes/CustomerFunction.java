package com.cognizant.shapes;

public class CustomerFunction {

}
